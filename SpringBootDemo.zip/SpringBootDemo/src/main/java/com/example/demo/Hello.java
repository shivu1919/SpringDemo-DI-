package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Hello {
	
	@Autowired
	Hyd h;
	
	

	public void hello() {
		h.hyd();
		
		System.out.println("I am saying Hello");
		}
}

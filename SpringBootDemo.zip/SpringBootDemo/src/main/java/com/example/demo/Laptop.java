package com.example.demo;

import org.springframework.stereotype.Component;

@Component
public class Laptop {
	public void main() {
		System.out.println(2+5);
	}
}

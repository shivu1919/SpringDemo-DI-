package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Hyd {
	
	@Autowired
	Laptop lap;
	public void hyd() {
		lap.main();
		System.out.println("This is coming from same container");
	}
}
